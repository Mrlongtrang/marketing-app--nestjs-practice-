export const jwtConstants = {
  secret: 'Longtrang1991', // replace with a strong secret for real projects
};
