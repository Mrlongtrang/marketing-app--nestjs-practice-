// src/modules/category/dto/update-category.dto.ts
export class UpdateCategoryDto {
  name?: string;
  description?: string;
}
